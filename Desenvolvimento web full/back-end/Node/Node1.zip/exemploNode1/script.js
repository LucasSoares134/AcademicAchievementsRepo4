document.getElementById('loadData').addEventListener('click', () => {
    fetch('http://localhost:3000/')
        .then(response => response.text())
        .then(data => {
            document.getElementById('apiResponse').textContent = data;
        })
        .catch(error => {
            console.error('Erro ao buscar dados:', error);
            document.getElementById('apiResponse').textContent = 'Erro ao carregar dados.';
        });
});

document.getElementById('loadSenac').addEventListener('click', () => {
    fetch('http://localhost:3000/senac')
        .then(response => response.text())
        .then(data => {
            document.getElementById('apiResponse').textContent = data;
        })
        .catch(error => {
            console.error('Erro ao buscar dados:', error);
            document.getElementById('apiResponse').textContent = 'Erro ao carregar dados.';
        });
});