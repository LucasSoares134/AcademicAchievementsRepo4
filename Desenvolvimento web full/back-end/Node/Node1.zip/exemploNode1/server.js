const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
const port = 3000;

app.get('/', (req, res) => {
  res.send('Olá, mundo!');
});

app.get('/senac', (req, res) => {
    res.send('Bem vindo(a) à faculdade SENAC!!!');
})

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
